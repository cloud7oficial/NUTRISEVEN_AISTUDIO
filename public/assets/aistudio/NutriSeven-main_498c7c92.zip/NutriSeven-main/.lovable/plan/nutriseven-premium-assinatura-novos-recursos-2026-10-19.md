# NutriSeven Premium: assinatura + novos recursos

## Modelo de venda
- **Grátis:** calculadora, criar conta, registrar peso de hoje.
- **Premium (assinatura mensal):** painel completo — histórico, notificações, gráfico de evolução, lista de compras, lembretes.
- Nova página **/planos** comparando Grátis x Premium, com botão "Assinar Premium".
- Landing ganha uma seção de preços e depoimentos-exemplo (marcados para você trocar pelos reais).

## Pagamento
- Cobrança real exige um plano pago do Lovable (Pro ou superior); hoje o seu workspace não tem. Até lá, deixo tudo pronto: o botão "Assinar" e o bloqueio do Premium funcionam, mas a cobrança fica para quando você fizer o upgrade.
- Depois do upgrade: ativo o pagamento (ambiente de teste primeiro, sem dinheiro real), crio o produto mensal e ligo o checkout.
- Preciso que você me diga o **preço mensal** (ex. R$ 19,90).

## Novos recursos (Premium)
1. **Gráfico de evolução** — linha de peso ao longo do tempo e mini-gráficos de cintura, quadril, braço, coxa e % de gordura, com filtro 30 dias / 90 dias / tudo.
2. **Lista de compras** — junta os alimentos do cardápio e calcula a quantidade para 7 dias (ex. "Arroz: 1,4 kg", "Ovos: 14 unidades"), com caixinhas para marcar o que já comprou e botão de copiar/compartilhar no WhatsApp.
3. **Lembretes de água e refeições** — meta de água pelo peso (35 ml por kg), botões "+1 copo (250 ml)" com barra de progresso diária salva no histórico; horários de cada refeição configuráveis e aviso no painel/navegador quando chegar a hora (com permissão de notificação do navegador, enquanto o app estiver aberto).

## Outras dicas para vender
- Domínio próprio (ex. nutriseven.com.br) passa mais confiança.
- Teste grátis de 7 dias do Premium para converter mais.
- Aviso "não substitui nutricionista" já existe — manter.

## Detalhes técnicos
- Tabelas novas: `subscriptions` (user_id, status, plano, fim do período — gravada só pelo servidor/webhook), `water_logs` (user_id, data, ml), `meal_reminders` (user_id, refeição, horário), `shopping_checks` (user_id, semana, item). RLS por usuário + GRANTs.
- Função `isPremium` lida do banco; painel bloqueia seções Premium com cartão "Desbloqueie no Premium".
- Gráficos com `recharts`; lista de compras calculada a partir de `suggestMeal` (gramas × 7, convertidos em medidas caseiras).
- Lembretes via `Notification` API + verificação a cada minuto com o app aberto (push com app fechado fica fora do escopo).
- Testes para: meta de água (35 ml/kg), multiplicação da lista semanal, regra de bloqueio Premium.
