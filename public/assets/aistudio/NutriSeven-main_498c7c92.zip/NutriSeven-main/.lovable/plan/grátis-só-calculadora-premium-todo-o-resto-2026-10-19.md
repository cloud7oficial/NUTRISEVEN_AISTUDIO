# Grátis = só calculadora; Premium = todo o resto

## Grátis
- Somente a **calculadora**: calorias, macros, nº de refeições e sugestão de cardápio com medidas caseiras.
- O botão **"⇄ Trocar" alimento fica bloqueado**: aparece com cadeado e, ao clicar, mostra "Trocar alimentos é Premium" com link para /planos.
- Pode criar conta e entrar, mas o painel mostra só uma tela "Seu painel é Premium" com a lista de benefícios e o botão "Assinar Premium".

## Premium
- Trocar alimentos na calculadora.
- Painel completo: cadastro, peso e medidas, plano do dia com marcação do que comeu, notificações, histórico, gráfico de evolução, lista de compras, água e lembretes.

## Ajustes de texto
- Preço do Premium passa para **R$ 14,99/mês** (planos e landing).
- Página de planos e cartões da landing atualizados: Grátis lista só a calculadora; "Trocar alimentos" e "Conta com peso e medidas" passam para Premium.
- Link "Minha conta" na calculadora continua; quem é Grátis cai na tela de upgrade.

## Detalhes técnicos
- Hook `usePremium()` (sessão atual + leitura de `subscriptions` + `isPremium`), usado na calculadora (rota pública, roda no navegador) e no painel.
- Calculadora: quando não Premium, `swap` não altera estado e exibe o aviso; o cardápio ignora trocas.
- Painel: se não Premium, renderiza só o componente de upgrade (nenhuma consulta de dados pessoais). Remove os vários cartões `Locked` individuais.
- Regra de liberação continua só pela tabela `subscriptions` (usuário não consegue se dar Premium).
- Teste: regra "trocar alimento exige Premium" (função `canSwapFood(premium)`).
