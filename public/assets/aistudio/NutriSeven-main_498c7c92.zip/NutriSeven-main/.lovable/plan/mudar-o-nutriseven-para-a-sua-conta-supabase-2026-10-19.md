# Mudar o NutriSeven para a sua conta Supabase

Este projeto não pode sair do Lovable Cloud. Por isso o caminho é um projeto novo, ligado à sua conta Supabase.

## Passo a passo (você faz)
1. Crie um projeto novo no Lovable. Não ative o Lovable Cloud quando ele for oferecido.
2. No projeto novo, abra a integração com Supabase e conecte a sua conta e um projeto Supabase seu.
3. Na sua conta Supabase, ative o login por e-mail/senha e por Google (o Google pede chaves criadas no Google Cloud).
4. No projeto novo, cole uma mensagem pedindo para recriar o NutriSeven. Abaixo tem um resumo pronto para colar.

## O que será recriado no projeto novo
- Página inicial, calculadora, planos, entrar/criar conta, painel e área Premium.
- Banco de dados: perfis, medidas, registro de consumo, água, lembretes, lista de compras, assinaturas, administradores.
- Novo: histórico de todos os cálculos. Cada vez que o usuário logado aperta "Calcular", ficam salvos os dados informados, os resultados, os macros, as refeições e os alimentos sugeridos. Tudo aparece na página "Meus cálculos".
- Premium só para quem está logado e tem assinatura ativa.

## O que não vai junto automaticamente
- Contas e dados de usuários que já existem aqui. Hoje há poucas contas de teste, então recomendo começar do zero.
- Você precisa definir de novo quem é administrador (rmic.suporte@gmail.com).

## Resumo para colar no projeto novo
"Recrie o app NutriSeven (pt-BR, tema verde e cinza-escuro, botões em formato de pílula, modo claro e escuro, bom no celular): landing em /, calculadora em /calculadora (Mifflin-St Jeor, macros, refeições, cardápio de preço baixo/médio/variado com medidas caseiras, troca de alimento só Premium), login com e-mail/senha e Google, painel com peso e medidas, consumo diário, notificações, gráfico, água, lista de compras, download dos dados, admin que ativa Premium por e-mail, plano Premium a R$ 14,99/mês. Salvar cada cálculo de usuários logados e mostrar em 'Meus cálculos'."

## Detalhes técnicos
- No projeto novo a conta é do Supabase do usuário (integração Supabase, não Cloud). As migrações SQL deste projeto (`drizzle/migrations/0000`–`0002`) podem ser copiadas para lá, mais a nova tabela `calculations` com RLS própria e GRANTs.
- Neste projeto nada é alterado.
