<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Routing

- `/` is the NutriSeven landing page and `/calculadora` is the calculator form. The landing is the
  first screen a client sees, so keep the calculator behind its CTA and never move it back to `/`.
- New pages get their own route file under `src/routes` with their own `head()` metadata; the
  landing copy and the calculator results must stay separate components.

- Signed-in area lives under `src/routes/_authenticated/` (`/painel`); profile, measurements and food logs are read/written from the browser client with per-user RLS — keeps the account flow simple with no extra server layer.
- Premium access is decided only by the `subscriptions` table (read-only to users, written by server/webhook) via `isPremium` in src/lib/premium.ts — users must not be able to grant themselves Premium.
- Only admins (role in `user_roles`, checked via `has_role`) can grant Premium, through the admin server functions in src/lib/admin.functions.ts (used by `/admin` and the panel tool); every change is logged to `subscription_events` (service-role only) — keeps self-granting impossible and gives an audit history.
