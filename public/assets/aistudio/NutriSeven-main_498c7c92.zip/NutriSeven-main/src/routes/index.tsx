import { createFileRoute, Link } from "@tanstack/react-router";
import { PlanCards } from "@/components/PlanCards";
import { usePremium } from "@/hooks/use-premium";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NutriSeven — Sua calculadora de calorias e macros" },
      { name: "description", content: "Descubra suas calorias diárias, a divisão de proteínas, gorduras e carboidratos e um plano de refeições feito para você." },
      { property: "og:title", content: "NutriSeven — Sua calculadora de calorias e macros" },
      { property: "og:description", content: "Calorias, macros e plano de refeições personalizados em segundos. Sem cadastro." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Landing,
});

const cta = "inline-flex items-center justify-center gap-2 rounded-full bg-primary px-9 py-4 text-[17px] font-semibold tracking-tight text-primary-foreground shadow-soft transition duration-200 ease-out hover:shadow-soft-lg hover:brightness-[1.06] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background active:scale-[0.985]";
const cta2 = "inline-flex items-center justify-center gap-2 rounded-full border border-primary/50 bg-card/60 px-9 py-4 text-[17px] font-semibold tracking-tight text-foreground shadow-soft backdrop-blur-sm transition duration-200 ease-out hover:border-primary hover:text-primary active:scale-[0.985]";

function Landing() {
  const { signedIn } = usePremium();
  return (
    <main className="relative min-h-screen overflow-hidden">
      <div className="hero-glow pointer-events-none absolute inset-0" aria-hidden="true" />

      <div className="relative mx-auto flex min-h-screen max-w-3xl flex-col items-center justify-center px-6 py-16 text-center">
        <span className="rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-primary">
          Sem cadastro · resultado em segundos
        </span>

        <h1 className="mt-8 text-5xl font-extrabold leading-[1.05] tracking-tighter sm:text-7xl">
          Nutri<span className="text-primary">Seven</span>
        </h1>

        <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">
          Diga seu sexo, idade, altura, peso, objetivo e nível de atividade. Em segundos você recebe
          suas <span className="font-semibold text-foreground">calorias diárias</span>, a divisão de{" "}
          <span className="font-semibold text-foreground">proteínas, gorduras e carboidratos</span> e um
          plano de <span className="font-semibold text-foreground">refeições</span> com as porções certas para cada momento do dia.
        </p>

        <div className="mt-10 flex flex-col items-center gap-4">
          {signedIn ? (
            <Link to="/painel" className={cta}>
              Ir para minha conta
              <span aria-hidden="true" className="text-lg leading-none">→</span>
            </Link>
          ) : (
            <>
              <div className="flex flex-col items-center gap-3 sm:flex-row">
                <Link to="/calculadora" className={cta}>
                  Calcular agora
                  <span aria-hidden="true" className="text-lg leading-none">→</span>
                </Link>
                <Link to="/auth" className={cta2}>Entrar ou criar conta</Link>
              </div>
              <p className="text-sm text-muted-foreground">Com conta, seus cálculos, metas e histórico ficam salvos.</p>
            </>
          )}
        </div>

        <ul className="mt-16 grid w-full gap-3 text-left sm:grid-cols-3">
          <F t="Calorias exatas" d="Seu gasto diário calculado a partir do seu corpo e da sua rotina." />
          <F t="Macros equilibrados" d="Quantos gramas de proteína, gordura e carboidrato por dia." />
          <F t="Refeições prontas" d="Quantas comer, quanto vai em cada uma e o que comer em cada prato." />
        </ul>

        <section className="mt-20 w-full">
          <h2 className="text-3xl font-bold tracking-tight">Planos</h2>
          <p className="mt-2 mb-8 text-muted-foreground">Comece grátis e evolua quando quiser.</p>
          <PlanCards />
        </section>

        <section className="mt-20 w-full">
          <h2 className="text-3xl font-bold tracking-tight">Quem usa, recomenda</h2>
          {/* EXEMPLOS: substituir por depoimentos reais de clientes */}
          <ul className="mt-8 grid gap-3 text-left sm:grid-cols-3">
            <F t="Ana, 34 · exemplo" d="“Finalmente entendi quanto comer. Perdi 4 kg em dois meses sem passar fome.”" />
            <F t="Carlos, 28 · exemplo" d="“A lista de compras da semana me poupa tempo e dinheiro no mercado.”" />
            <F t="Juliana, 41 · exemplo" d="“Os lembretes de água mudaram minha rotina. Ver o gráfico caindo motiva!”" />
          </ul>
        </section>

        <p className="mt-14 text-xs text-muted-foreground">
          Estimativas gerais. Consulte um nutricionista para orientação individual.
        </p>
      </div>
    </main>
  );
}

function F({ t, d }: { t: string; d: string }) {
  return (
    <li className="rounded-2xl border border-border bg-card/60 p-5 backdrop-blur-sm">
      <p className="text-sm font-semibold text-foreground">{t}</p>
      <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{d}</p>
    </li>
  );
}
