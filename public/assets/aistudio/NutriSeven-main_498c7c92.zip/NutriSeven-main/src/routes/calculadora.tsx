import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { calculate, type Input, type Activity, type Goal, type Sex } from "@/lib/nutrition";
import { suggestMeal, type Budget } from "@/lib/meals";
import { usePremium } from "@/hooks/use-premium";
import { canSwapFood } from "@/lib/premium";

export const Route = createFileRoute("/calculadora")({
  head: () => ({
    meta: [
      { title: "Calculadora — NutriSeven" },
      { name: "description", content: "Calcule suas calorias diárias, proteínas, gorduras, carboidratos e a divisão ideal por refeição." },
      { property: "og:title", content: "Calculadora — NutriSeven" },
      { property: "og:description", content: "Calorias, macros e plano de refeições personalizados em segundos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Calculadora,
});

const field = "w-full rounded-md border border-input bg-input/40 px-3 py-2 text-foreground outline-none focus:border-primary";

function Calculadora() {
  const [f, setF] = useState({ sex: "male" as Sex, age: "30", height: "175", weight: "75", goal: "maintain" as Goal, activity: "moderate" as Activity });
  const [res, setRes] = useState<ReturnType<typeof calculate> | null>(null);
  const [budget, setBudget] = useState<Budget | null>(null);
  const [swaps, setSwaps] = useState<Record<string, number[]>>({});
  const { premium } = usePremium();
  const [lockMsg, setLockMsg] = useState(false);
  const swap = (key: string, j: number) => {
    if (!canSwapFood(premium)) return setLockMsg(true);
    setSwaps((s) => {
      const arr = [...(s[key] ?? [])];
      arr[j] = (arr[j] ?? 0) + 1;
      return { ...s, [key]: arr };
    });
  };
  const [err, setErr] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const age = +f.age, height = +f.height, weight = +f.weight;
    if (!(age >= 15 && age <= 100 && height >= 120 && height <= 230 && weight >= 30 && weight <= 300)) {
      setErr("Verifique os valores: idade 15–100, altura 120–230 cm, peso 30–300 kg.");
      return;
    }
    setErr("");
    setRes(calculate({ ...f, age, height, weight } as Input));
  };

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });

  return (
    <main className="mx-auto min-h-screen max-w-3xl px-4 py-12">
      <header className="mb-10 text-center">
        <div className="flex justify-between text-xs uppercase tracking-wider text-muted-foreground">
          <Link to="/" className="transition-colors hover:text-primary">← Início</Link>
          <Link to="/painel" className="transition-colors hover:text-primary">Minha conta →</Link>
        </div>
        <h1 className="mt-3 text-4xl font-bold tracking-tight">Nutri<span className="text-primary">Seven</span></h1>
        <p className="mt-2 text-muted-foreground">Calorias e macronutrientes sob medida para você.</p>
      </header>

      <form onSubmit={submit} className="grid gap-4 rounded-xl border border-border bg-card p-6 sm:grid-cols-2">
        <L t="Sexo"><select className={field} value={f.sex} onChange={set("sex")}><option value="male">Masculino</option><option value="female">Feminino</option></select></L>
        <L t="Idade (anos)"><input type="number" className={field} value={f.age} onChange={set("age")} /></L>
        <L t="Altura (cm)"><input type="number" className={field} value={f.height} onChange={set("height")} /></L>
        <L t="Peso (kg)"><input type="number" step="0.1" className={field} value={f.weight} onChange={set("weight")} /></L>
        <L t="Objetivo"><select className={field} value={f.goal} onChange={set("goal")}><option value="lose">Perder peso</option><option value="maintain">Manter o peso</option><option value="gain">Ganhar peso</option></select></L>
        <L t="Nível de atividade"><select className={field} value={f.activity} onChange={set("activity")}>
          <option value="sedentary">Sedentário</option><option value="light">Leve (1–3x/sem)</option><option value="moderate">Moderado (3–5x/sem)</option><option value="active">Ativo (6–7x/sem)</option><option value="very">Muito ativo</option>
        </select></L>
        {err && <p className="text-sm text-destructive sm:col-span-2">{err}</p>}
        <button className="rounded-full bg-primary px-8 py-3.5 text-[15px] font-semibold tracking-tight text-primary-foreground shadow-soft transition duration-200 ease-out hover:shadow-soft-lg hover:brightness-[1.06] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background active:scale-[0.985] sm:col-span-2">Calcular</button>
      </form>

      {res && (
        <section className="mt-8 space-y-6">
          <div className="rounded-xl border border-primary/40 bg-card p-6 text-center">
            <p className="text-sm uppercase tracking-wider text-muted-foreground">Calorias diárias</p>
            <p className="mt-1 text-5xl font-bold text-primary">{res.calories}<span className="ml-1 text-xl text-muted-foreground">kcal</span></p>
            <p className="mt-2 text-xs text-muted-foreground">Metabolismo basal {res.bmr} kcal · Gasto total {res.tdee} kcal</p>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <M n="Proteínas" g={res.protein} k={res.protein * 4} />
            <M n="Gorduras" g={res.fat} k={res.fat * 9} />
            <M n="Carboidratos" g={res.carbs} k={res.carbs * 4} />
          </div>
          {premium ? (
          <div className="rounded-xl border border-border bg-card p-6">
            <h2 className="text-lg font-semibold">Sugestão: <span className="text-primary">{res.meals} refeições</span> por dia</h2>
            <p className="mt-4 text-sm text-muted-foreground">Que tipo de cardápio você prefere?</p>
            <div className="mt-2 grid grid-cols-3 gap-2">
              {([["low", "Preço baixo"], ["medium", "Preço médio"], ["varied", "Variado"]] as [Budget, string][]).map(([v, t]) => (
                <button key={v} type="button" onClick={() => setBudget(v)}
                  className={`rounded-md border py-2 text-sm transition ${budget === v ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-primary"}`}>{t}</button>
              ))}
            </div>
            {lockMsg && (
              <p role="status" className="mt-4 rounded-lg border border-primary/50 bg-primary/10 p-3 text-sm">
                Trocar alimentos é Premium. <Link to="/planos" className="font-semibold text-primary underline">Conheça o Premium</Link>
              </p>
            )}
            <ul className="mt-4 divide-y divide-border">
              {res.mealPlan.map((m, i) => (
                <li key={m.name} className="py-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{m.name} <span className="text-xs text-muted-foreground">({m.pct}%)</span></span>
                    <span className="font-semibold text-primary">{m.calories} kcal</span>
                  </div>
                  {budget && (
                    <ul className="mt-2 space-y-1 text-sm">
                      {suggestMeal(m.name, m.calories, budget, i, premium ? swaps[`${budget}-${m.name}`] : []).map((it, j) => (
                        <li key={j} className="flex items-center justify-between gap-2 text-muted-foreground">
                          <span>• <span className={it.swapped ? "text-primary" : ""}>{it.name}</span> <span className="text-xs">({it.pct}%)</span></span>
                          <span className="flex items-center gap-2 text-right text-foreground">
                            <span>{it.measure} <span className="text-xs text-muted-foreground">(~{it.grams}{it.unit} · {it.kcal} kcal)</span></span>
                            {it.swappable && (
                              <button type="button" title="Trocar por alternativa semelhante" aria-label={`Trocar ${it.name}`}
                                onClick={() => swap(`${budget}-${m.name}`, j)}
                                className="rounded border border-border px-2 py-0.5 text-xs hover:border-primary hover:text-primary">{premium ? "⇄ Trocar" : "🔒 Trocar"}</button>
                            )}
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              ))}
            </ul>
          </div>
          ) : (
            <LockedMenu meals={res.mealPlan} count={res.meals} />
          )}
          {!premium && <LockedFeatures />}
          <p className="text-center text-xs text-muted-foreground">Estimativas gerais. Consulte um nutricionista para orientação individual.</p>
        </section>
      )}
    </main>
  );
}

function L({ t, children }: { t: string; children: React.ReactNode }) {
  return <label className="space-y-1 text-sm"><span className="text-muted-foreground">{t}</span>{children}</label>;
}

function M({ n, g, k }: { n: string; g: number; k: number }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 text-center">
      <p className="text-xs uppercase tracking-wider text-muted-foreground">{n}</p>
      <p className="mt-1 text-2xl font-bold">{g}g</p>
      <p className="text-xs text-primary">{k} kcal</p>
    </div>
  );
}

const unlock = "inline-block rounded-full bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground shadow-soft transition hover:brightness-[1.06] active:scale-[0.985]";

function LockedMenu({ meals, count }: { meals: { name: string; pct: number; calories: number }[]; count: number }) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card p-6">
      <h2 className="text-lg font-semibold">Sugestão: <span className="text-primary">{count} refeições</span> por dia</h2>
      <div aria-hidden="true" className="pointer-events-none mt-4 select-none blur-[5px]">
        {meals.map((m) => (
          <div key={m.name} className="border-b border-border py-3">
            <div className="flex justify-between"><span className="font-medium">{m.name}</span><span className="text-primary">{m.calories} kcal</span></div>
            <p className="mt-1 text-sm text-muted-foreground">• Arroz 4 colheres · Frango 1 filé · Salada à vontade</p>
          </div>
        ))}
      </div>
      <div className="absolute inset-0 top-14 flex flex-col items-center justify-center gap-3 bg-background/40 px-6 text-center">
        <p className="text-3xl">🔒</p>
        <p className="font-semibold">Cardápio completo é Premium</p>
        <p className="max-w-sm text-sm text-muted-foreground">O que comer em cada refeição, porções em colheres e xícaras e troca de alimentos.</p>
        <Link to="/planos" className={unlock}>Desbloquear cardápio</Link>
      </div>
    </div>
  );
}

function LockedFeatures() {
  const items = [
    ["📈", "Gráfico de evolução", "Peso e medidas semana a semana."],
    ["✅", "Registro do que comeu", "Marque o consumo e receba alertas de excesso."],
    ["🛒", "Lista de compras", "Sua feira da semana com 1 clique, pronta para o WhatsApp."],
    ["💧", "Lembretes de água e refeições", "Meta de hidratação e horários certos."],
  ];
  return (
    <div className="rounded-xl border border-primary/30 bg-card p-6">
      <p className="text-xs font-semibold uppercase tracking-wider text-primary">Premium</p>
      <h2 className="mt-1 text-lg font-semibold">Leve seu resultado além</h2>
      <ul className="mt-4 grid gap-3 sm:grid-cols-2">
        {items.map(([i, t, d]) => (
          <li key={t} className="relative rounded-lg border border-border bg-muted/30 p-4 opacity-80">
            <span className="absolute right-3 top-3 text-sm" aria-label="Bloqueado">🔒</span>
            <p className="font-medium">{i} {t}</p>
            <p className="mt-1 text-sm text-muted-foreground">{d}</p>
          </li>
        ))}
      </ul>
      <div className="mt-5 text-center"><Link to="/planos" className={unlock}>Desbloquear tudo no Premium</Link></div>
    </div>
  );
}
