import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { lovable } from "@/integrations/lovable/index";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar — NutriSeven" },
      { name: "description", content: "Entre no NutriSeven para salvar peso, medidas e acompanhar seu consumo diário." },
      { property: "og:title", content: "Entrar — NutriSeven" },
      { property: "og:description", content: "Salve seu progresso e acompanhe sua alimentação todos os dias." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

const field = "w-full rounded-md border border-input bg-input/40 px-3 py-2.5 text-foreground outline-none focus:border-primary";
const primary = "w-full rounded-full bg-primary px-6 py-3.5 text-[15px] font-semibold tracking-tight text-primary-foreground shadow-soft transition hover:brightness-[1.06] active:scale-[0.985] disabled:opacity-60";

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/painel", replace: true });
    });
    const { data } = supabase.auth.onAuthStateChange((_e, s) => {
      if (s) navigate({ to: "/painel", replace: true });
    });
    return () => data.subscription.unsubscribe();
  }, [navigate]);

  const google = async () => {
    setBusy(true); setErr("");
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/auth" });
    if (r.error) { setErr("Não foi possível entrar com o Google. Tente novamente."); setBusy(false); return; }
    if (r.redirected) return;
    navigate({ to: "/painel", replace: true });
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(""); setInfo("");
    if (password.length < 6) return setErr("A senha precisa ter pelo menos 6 caracteres.");
    setBusy(true);
    if (mode === "up") {
      const { data, error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin + "/auth" } });
      setBusy(false);
      if (error) return setErr(error.message.includes("registered") ? "Este e-mail já tem cadastro. Entre com sua senha." : "Não foi possível criar a conta.");
      if (!data.session) setInfo("Conta criada! Confira seu e-mail e clique no link de confirmação para entrar.");
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setBusy(false);
      if (error) setErr(error.message.includes("confirmed") ? "Confirme seu e-mail antes de entrar." : "E-mail ou senha incorretos.");
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-sm rounded-2xl border border-border bg-card p-8 text-center">
        <Link to="/" className="text-xs uppercase tracking-wider text-muted-foreground hover:text-primary">← Início</Link>
        <h1 className="mt-4 text-3xl font-bold tracking-tight">Nutri<span className="text-primary">Seven</span></h1>
        <p className="mt-2 text-sm text-muted-foreground">Crie sua conta para salvar peso, medidas e acompanhar seu consumo todos os dias.</p>

        <div className="mt-6 grid grid-cols-2 rounded-full bg-muted p-1 text-sm">
          {([["in", "Entrar"], ["up", "Criar conta"]] as const).map(([m, t]) => (
            <button key={m} type="button" onClick={() => { setMode(m); setErr(""); setInfo(""); }}
              className={`rounded-full py-2 transition ${mode === m ? "bg-card font-semibold text-foreground shadow-soft" : "text-muted-foreground"}`}>{t}</button>
          ))}
        </div>

        <form onSubmit={submit} className="mt-5 space-y-3 text-left">
          <input type="email" required placeholder="seu@email.com" autoComplete="email" className={field} value={email} onChange={(e) => setEmail(e.target.value)} />
          <input type="password" required placeholder="Senha (mín. 6 caracteres)" autoComplete={mode === "up" ? "new-password" : "current-password"} className={field} value={password} onChange={(e) => setPassword(e.target.value)} />
          <button disabled={busy} className={primary}>{busy ? "Aguarde…" : mode === "up" ? "Criar conta" : "Entrar"}</button>
        </form>

        <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />ou<span className="h-px flex-1 bg-border" /></div>
        <button onClick={google} disabled={busy} className="w-full rounded-full border border-border px-6 py-3 text-[15px] font-semibold transition hover:border-primary disabled:opacity-60">
          Continuar com Google
        </button>
        {err && <p className="mt-4 text-sm text-destructive">{err}</p>}
        {info && <p className="mt-4 text-sm text-primary">{info}</p>}
      </div>
    </main>
  );
}
