import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { calculate, type Activity, type Goal, type Sex } from "@/lib/nutrition";
import { suggestMeal, type Budget } from "@/lib/meals";
import { today, fmtDate } from "@/lib/dates";
import { buildAlerts } from "@/lib/alerts";
import { usePremium } from "@/hooks/use-premium";
import { PlanCards } from "@/components/PlanCards";
import { EvolutionChart, Locked, ShoppingList, WaterReminders } from "@/components/PremiumSections";
import { AdminPremium, DownloadData } from "@/components/PanelTools";

export const Route = createFileRoute("/_authenticated/painel")({
  head: () => ({
    meta: [
      { title: "Meu painel — NutriSeven" },
      { name: "description", content: "Seu peso, medidas, plano do dia e histórico de consumo no NutriSeven." },
      { property: "og:title", content: "Meu painel — NutriSeven" },
      { property: "og:description", content: "Acompanhe sua evolução e confirme o que comeu todos os dias." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PainelGate,
});

const field = "w-full rounded-md border border-input bg-input/40 px-3 py-2 text-foreground outline-none focus:border-primary";
const card = "rounded-xl border border-border bg-card p-6";
const btn = "rounded-full bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground shadow-soft transition hover:brightness-[1.06] active:scale-[0.985] disabled:opacity-60";

function AdminLink({ userId }: { userId: string }) {
  const admin = useQuery({
    queryKey: ["is_admin", userId],
    queryFn: async () => (await supabase.rpc("has_role", { _user_id: userId, _role: "admin" })).data === true,
  });
  if (!admin.data) return null;
  return <Link to="/admin" className="font-semibold text-primary hover:underline">Admin</Link>;
}

function PainelGate() {
  const { premium, loading } = usePremium();
  if (loading) return <main className="flex min-h-screen items-center justify-center text-muted-foreground">Carregando…</main>;
  return premium ? <Painel /> : <Upgrade />;
}

function Upgrade() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const signOut = async () => { await qc.cancelQueries(); qc.clear(); await supabase.auth.signOut(); navigate({ to: "/auth", replace: true }); };
  return (
    <main className="mx-auto min-h-screen max-w-3xl px-4 py-12 text-center">
      <header className="mb-10 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold tracking-tight">Nutri<span className="text-primary">Seven</span></Link>
        <div className="flex gap-4 text-sm"><AdminLink userId={user.id} /><button onClick={signOut} className="text-muted-foreground hover:text-primary">Sair</button></div>
      </header>
      <h1 className="text-3xl font-bold tracking-tight">Seu painel é <span className="text-primary">Premium</span></h1>
      <p className="mt-2 mb-8 text-muted-foreground">No plano Grátis você usa a calculadora. Assine para acompanhar peso, consumo e evolução todos os dias.</p>
      <PlanCards />
      <div className="mt-8"><AdminPremium userId={user.id} /></div>
    </main>
  );
}

function Painel() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const day = today();

  const profile = useQuery({
    queryKey: ["profile", user.id],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
      if (data) return data;
      const { data: created } = await supabase.from("profiles").insert({ id: user.id }).select().single();
      return created!;
    },
  });
  const measures = useQuery({
    queryKey: ["measurements", user.id],
    queryFn: async () => (await supabase.from("measurements").select("*").order("measured_on", { ascending: false }).order("created_at", { ascending: false }).limit(60)).data ?? [],
  });
  const premium = true; // PainelGate only renders this for Premium users
  const logs = useQuery({
    queryKey: ["food_logs", user.id],
    queryFn: async () => {
      const since = new Date(); since.setDate(since.getDate() - 30);
      return (await supabase.from("food_logs").select("*").gte("log_date", today(since)).order("log_date", { ascending: false })).data ?? [];
    },
  });

  const p = profile.data;
  const latest = measures.data?.[0];
  const plan = useMemo(() => p && latest ? calculate({ sex: p.sex as Sex, age: p.age, height: Number(p.height), weight: Number(latest.weight), goal: p.goal as Goal, activity: p.activity as Activity }) : null, [p, latest]);
  const todayLogs = (logs.data ?? []).filter((l) => l.log_date === day);
  const eaten = todayLogs.reduce((s, l) => s + l.kcal, 0);

  const toggle = async (meal: string, food: string, measure: string, kcal: number) => {
    const existing = todayLogs.find((l) => l.meal_name === meal && l.food_name === food);
    if (existing) await supabase.from("food_logs").delete().eq("id", existing.id);
    else await supabase.from("food_logs").insert({ user_id: user.id, log_date: day, meal_name: meal, food_name: food, measure, kcal, target_kcal: plan?.calories ?? null });
    qc.invalidateQueries({ queryKey: ["food_logs", user.id] });
  };

  const signOut = async () => {
    await qc.cancelQueries(); qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  const history = useMemo(() => {
    const m = new Map<string, { kcal: number; target: number | null; items: number }>();
    for (const l of logs.data ?? []) {
      const e = m.get(l.log_date) ?? { kcal: 0, target: l.target_kcal, items: 0 };
      e.kcal += l.kcal; e.items++; m.set(l.log_date, e);
    }
    return [...m.entries()].slice(0, 14);
  }, [logs.data]);

  return (
    <main className="mx-auto min-h-screen max-w-3xl space-y-6 px-4 py-10">
      <header className="flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold tracking-tight">Nutri<span className="text-primary">Seven</span></Link>
        <div className="flex items-center gap-4 text-sm">
          <AdminLink userId={user.id} />
          <button onClick={signOut} className="text-muted-foreground hover:text-primary">Sair</button>
        </div>
      </header>
      <p className="text-muted-foreground">Olá{p?.name ? `, ${p.name.split(" ")[0]}` : ""}! Hoje é {fmtDate(day)}.</p>

      {premium ? (() => {
        const alerts = buildAlerts({
          measures: measures.data ?? [],
          target: plan?.calories ?? null,
          eaten,
          meals: plan?.mealPlan ?? [],
          doneMeals: new Set(todayLogs.map((l) => l.meal_name)),
          goal: p?.goal ?? "maintain",
          loggedDays: new Set((logs.data ?? []).map((l) => l.log_date)).size,
        });
        if (!alerts.length) return null;
        const tone = { warn: "border-destructive/50 bg-destructive/10", good: "border-primary/50 bg-primary/10", info: "border-border bg-card" };
        return (
          <section aria-label="Notificações" className="space-y-3">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">🔔 Notificações</h2>
            {alerts.map((a) => (
              <div key={a.title} role="status" className={`rounded-xl border p-4 ${tone[a.tone]}`}>
                <p className="font-semibold">{a.title}</p>
                <p className="mt-1 text-sm text-muted-foreground">{a.text}</p>
              </div>
            ))}
          </section>
        );
      })() : <Locked title="Notificações de progresso" text="Alertas quando o peso muda muito ou quando passa da meta, com sugestões." />}

      {p && <ProfileForm p={p} onSaved={() => qc.invalidateQueries({ queryKey: ["profile", user.id] })} />}
      <MeasureForm userId={user.id} last={latest} onSaved={() => qc.invalidateQueries({ queryKey: ["measurements", user.id] })} />

      <section className={card}>
        <h2 className="text-lg font-semibold">Plano de hoje</h2>
        {!plan ? <p className="mt-2 text-sm text-muted-foreground">Registre seu peso acima para gerar o plano do dia.</p> : (
          <>
            <div className="mt-4 flex items-end justify-between">
              <p><span className="text-3xl font-bold text-primary">{eaten}</span> <span className="text-muted-foreground">/ {plan.calories} kcal</span></p>
              <p className="text-xs text-muted-foreground">P {plan.protein}g · G {plan.fat}g · C {plan.carbs}g</p>
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-muted">
              <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${Math.min(100, (eaten / plan.calories) * 100)}%` }} />
            </div>
            <p className="mt-4 text-xs text-muted-foreground">Marque cada alimento que você comeu.</p>
            <ul className="mt-2 divide-y divide-border">
              {plan.mealPlan.map((m, i) => (
                <li key={m.name} className="py-4">
                  <div className="flex justify-between"><span className="font-medium">{m.name}</span><span className="text-sm text-primary">{m.calories} kcal</span></div>
                  <ul className="mt-2 space-y-1.5">
                    {suggestMeal(m.name, m.calories, p!.budget as Budget, i).map((it) => {
                      const done = todayLogs.some((l) => l.meal_name === m.name && l.food_name === it.name);
                      return (
                        <li key={it.name}>
                          <label className="flex cursor-pointer items-center gap-3 text-sm">
                            <input type="checkbox" checked={done} onChange={() => toggle(m.name, it.name, it.measure, it.kcal)} className="h-4 w-4 accent-[var(--color-primary)]" />
                            <span className={done ? "text-muted-foreground line-through" : ""}>{it.name}</span>
                            <span className="ml-auto text-right text-muted-foreground">{it.measure} · {it.kcal} kcal</span>
                          </label>
                        </li>
                      );
                    })}
                  </ul>
                </li>
              ))}
            </ul>
          </>
        )}
      </section>

      {premium ? (
      <section className={card}>
        <h2 className="text-lg font-semibold">Histórico de consumo</h2>
        {history.length === 0 ? <p className="mt-2 text-sm text-muted-foreground">Nenhum consumo registrado ainda.</p> : (
          <ul className="mt-3 space-y-2 text-sm">
            {history.map(([d, e]) => {
              const pct = e.target ? Math.round((e.kcal / e.target) * 100) : null;
              return (
                <li key={d} className="flex items-center gap-3">
                  <span className="w-16 text-muted-foreground">{fmtDate(d)}</span>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted"><div className="h-full bg-primary" style={{ width: `${Math.min(100, pct ?? 0)}%` }} /></div>
                  <span className="w-32 text-right">{e.kcal} kcal{pct !== null && <span className="text-muted-foreground"> ({pct}%)</span>}</span>
                </li>
              );
            })}
          </ul>
        )}
      </section>
      ) : <Locked title="Histórico de consumo" text="Veja quanto comeu em cada dia em relação à sua meta." />}

      <section className={card}>
        <h2 className="text-lg font-semibold">Evolução das medidas</h2>
        {!measures.data?.length ? <p className="mt-2 text-sm text-muted-foreground">Sem registros ainda.</p> : (
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-xs uppercase text-muted-foreground">
                <tr><th className="py-2">Data</th><th>Peso</th><th>Cintura</th><th>Quadril</th><th>Braço</th><th>Coxa</th><th>% Gord.</th></tr>
              </thead>
              <tbody className="divide-y divide-border">
                {measures.data.map((r, i) => {
                  const prev = measures.data[i + 1];
                  const diff = prev ? Number(r.weight) - Number(prev.weight) : 0;
                  return (
                    <tr key={r.id}>
                      <td className="py-2 text-muted-foreground">{fmtDate(r.measured_on)}</td>
                      <td>{Number(r.weight)} kg {diff !== 0 && <span className="text-xs text-primary">({diff > 0 ? "+" : ""}{diff.toFixed(1)})</span>}</td>
                      <td>{r.waist ?? "—"}</td><td>{r.hip ?? "—"}</td><td>{r.arm ?? "—"}</td><td>{r.thigh ?? "—"}</td><td>{r.body_fat ?? "—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {premium ? (
        <>
          <EvolutionChart data={measures.data ?? []} />
          {plan && p && <WaterReminders userId={user.id} weight={Number(latest!.weight)} meals={plan.mealPlan.map((m) => m.name)} />}
          {plan && p && <ShoppingList userId={user.id} meals={plan.mealPlan} budget={p.budget as Budget} />}
        </>
      ) : (
        <>
          <Locked title="Gráfico de evolução" text="Veja seu peso e suas medidas mudando ao longo do tempo." />
          <Locked title="Água, lembretes e lista de compras" text="Meta de água diária, avisos na hora das refeições e a lista de compras da semana pronta." />
        </>
      )}
      <DownloadData userId={user.id} />
      <AdminPremium userId={user.id} />
    </main>
  );
}

type Profile = { id: string; name: string | null; sex: string; age: number; height: number; goal: string; activity: string; budget: string };

function ProfileForm({ p, onSaved }: { p: Profile; onSaved: () => void }) {
  const [f, setF] = useState({ name: p.name ?? "", sex: p.sex, age: String(p.age), height: String(p.height), goal: p.goal, activity: p.activity, budget: p.budget });
  const [msg, setMsg] = useState("");
  useEffect(() => setMsg(""), [f]);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    const age = +f.age, height = +f.height;
    if (!(age >= 15 && age <= 100 && height >= 120 && height <= 230)) return setMsg("Idade 15–100 e altura 120–230 cm.");
    const { error } = await supabase.from("profiles").update({ ...f, age, height, updated_at: new Date().toISOString() }).eq("id", p.id);
    setMsg(error ? "Erro ao salvar." : "Perfil salvo ✓");
    if (!error) onSaved();
  };
  return (
    <form onSubmit={save} className={`${card} grid gap-4 sm:grid-cols-2`}>
      <h2 className="text-lg font-semibold sm:col-span-2">Meu cadastro</h2>
      <L t="Nome"><input className={field} value={f.name} onChange={set("name")} /></L>
      <L t="Sexo"><select className={field} value={f.sex} onChange={set("sex")}><option value="male">Masculino</option><option value="female">Feminino</option></select></L>
      <L t="Idade"><input type="number" className={field} value={f.age} onChange={set("age")} /></L>
      <L t="Altura (cm)"><input type="number" className={field} value={f.height} onChange={set("height")} /></L>
      <L t="Objetivo"><select className={field} value={f.goal} onChange={set("goal")}><option value="lose">Perder peso</option><option value="maintain">Manter o peso</option><option value="gain">Ganhar peso</option></select></L>
      <L t="Nível de atividade"><select className={field} value={f.activity} onChange={set("activity")}>
        <option value="sedentary">Sedentário</option><option value="light">Leve (1–3x/sem)</option><option value="moderate">Moderado (3–5x/sem)</option><option value="active">Ativo (6–7x/sem)</option><option value="very">Muito ativo</option>
      </select></L>
      <L t="Cardápio"><select className={field} value={f.budget} onChange={set("budget")}><option value="low">Preço baixo</option><option value="medium">Preço médio</option><option value="varied">Variado</option></select></L>
      <div className="flex items-end gap-3"><button className={btn}>Salvar perfil</button>{msg && <span className="text-sm text-muted-foreground">{msg}</span>}</div>
    </form>
  );
}

type Measure = { weight: number; waist: number | null; hip: number | null; arm: number | null; thigh: number | null; body_fat: number | null };

function MeasureForm({ userId, last, onSaved }: { userId: string; last: Measure | undefined; onSaved: () => void }) {
  const init = (v: number | null | undefined) => (v == null ? "" : String(v));
  const [f, setF] = useState({ weight: "", waist: "", hip: "", arm: "", thigh: "", body_fat: "" });
  useEffect(() => {
    if (last) setF({ weight: init(last.weight), waist: init(last.waist), hip: init(last.hip), arm: init(last.arm), thigh: init(last.thigh), body_fat: init(last.body_fat) });
  }, [last]);
  const [msg, setMsg] = useState("");
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => { setMsg(""); setF({ ...f, [k]: e.target.value }); };
  const num = (v: string) => (v.trim() === "" ? null : Number(v));
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    const weight = Number(f.weight);
    if (!(weight >= 30 && weight <= 300)) return setMsg("Informe um peso entre 30 e 300 kg.");
    const bf = num(f.body_fat);
    if (bf !== null && !(bf >= 2 && bf <= 70)) return setMsg("% de gordura entre 2 e 70.");
    const { error } = await supabase.from("measurements").insert({ user_id: userId, measured_on: today(), weight, waist: num(f.waist), hip: num(f.hip), arm: num(f.arm), thigh: num(f.thigh), body_fat: bf });
    setMsg(error ? "Erro ao salvar." : "Medidas registradas ✓");
    if (!error) onSaved();
  };
  return (
    <form onSubmit={save} className={`${card} grid grid-cols-2 gap-4 sm:grid-cols-3`}>
      <h2 className="col-span-full text-lg font-semibold">Registrar peso e medidas de hoje</h2>
      <L t="Peso (kg) *"><input type="number" step="0.1" className={field} value={f.weight} onChange={set("weight")} /></L>
      <L t="Cintura (cm)"><input type="number" step="0.1" className={field} value={f.waist} onChange={set("waist")} /></L>
      <L t="Quadril (cm)"><input type="number" step="0.1" className={field} value={f.hip} onChange={set("hip")} /></L>
      <L t="Braço (cm)"><input type="number" step="0.1" className={field} value={f.arm} onChange={set("arm")} /></L>
      <L t="Coxa (cm)"><input type="number" step="0.1" className={field} value={f.thigh} onChange={set("thigh")} /></L>
      <L t="% de gordura"><input type="number" step="0.1" className={field} value={f.body_fat} onChange={set("body_fat")} /></L>
      <div className="col-span-full flex items-center gap-3"><button className={btn}>Salvar medidas</button>{msg && <span className="text-sm text-muted-foreground">{msg}</span>}</div>
    </form>
  );
}

function L({ t, children }: { t: string; children: React.ReactNode }) {
  return <label className="space-y-1 text-sm"><span className="text-muted-foreground">{t}</span>{children}</label>;
}
