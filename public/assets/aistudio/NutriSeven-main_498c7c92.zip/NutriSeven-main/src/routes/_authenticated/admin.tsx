import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { listUsersAdmin, setPremiumById } from "@/lib/admin.functions";
import { isPremium } from "@/lib/premium";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Administração — NutriSeven" },
      { name: "description", content: "Usuários, planos e histórico de assinaturas do NutriSeven." },
      { property: "og:title", content: "Administração — NutriSeven" },
      { property: "og:description", content: "Gestão de usuários e assinaturas." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Admin,
});

const d = (s: string | null) => (s ? new Date(s).toLocaleDateString("pt-BR") : "—");

function Admin() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const list = useServerFn(listUsersAdmin);
  const setP = useServerFn(setPremiumById);
  const admin = useQuery({
    queryKey: ["is_admin", user.id],
    queryFn: async () => (await supabase.rpc("has_role", { _user_id: user.id, _role: "admin" })).data === true,
  });
  const users = useQuery({ queryKey: ["admin_users"], enabled: admin.data === true, queryFn: () => list() });
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  if (admin.isLoading) return <main className="flex min-h-screen items-center justify-center text-muted-foreground">Carregando…</main>;
  if (!admin.data) return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 px-4 text-center">
      <p className="text-lg font-semibold">Acesso restrito a administradores.</p>
      <Link to="/painel" className="text-primary underline">Voltar ao painel</Link>
    </main>
  );

  const toggle = async (id: string, active: boolean) => {
    setBusy(id);
    try { await setP({ data: { userId: id, active } }); await qc.invalidateQueries({ queryKey: ["admin_users"] }); qc.invalidateQueries({ queryKey: ["subscription"] }); }
    finally { setBusy(null); }
  };
  const rows = (users.data ?? []).filter((u) => u.email.toLowerCase().includes(q.toLowerCase()));
  const premiumCount = (users.data ?? []).filter((u) => isPremium(u.status ? { status: u.status, current_period_end: u.current_period_end } : null)).length;

  return (
    <main className="mx-auto min-h-screen max-w-4xl px-4 py-10">
      <header className="mb-8 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold tracking-tight">Nutri<span className="text-primary">Seven</span></Link>
        <Link to="/painel" className="text-sm text-muted-foreground hover:text-primary">← Painel</Link>
      </header>
      <h1 className="text-3xl font-bold tracking-tight">Administração</h1>
      <div className="mt-6 grid grid-cols-3 gap-3">
        <Stat t="Usuários" v={users.data?.length ?? 0} />
        <Stat t="Premium" v={premiumCount} />
        <Stat t="Grátis" v={(users.data?.length ?? 0) - premiumCount} />
      </div>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por e-mail"
        className="mt-6 w-full rounded-full border border-input bg-input/40 px-4 py-2.5 text-foreground outline-none focus:border-primary" />
      {users.isLoading && <p className="mt-6 text-muted-foreground">Carregando usuários…</p>}
      {users.error && <p className="mt-6 text-destructive">Erro ao carregar usuários.</p>}
      <ul className="mt-4 space-y-3">
        {rows.map((u) => {
          const prem = isPremium(u.status ? { status: u.status, current_period_end: u.current_period_end } : null);
          return (
            <li key={u.id} className="rounded-xl border border-border bg-card p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate font-medium">{u.email || "(sem e-mail)"}</p>
                  <p className="text-xs text-muted-foreground">Cadastro {d(u.created_at)} · Último acesso {d(u.last_sign_in_at)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`rounded-full px-3 py-1 text-xs font-semibold ${prem ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                    {prem ? `Premium até ${d(u.current_period_end)}` : "Grátis"}
                  </span>
                  <button disabled={busy === u.id} onClick={() => toggle(u.id, !prem)}
                    className={`rounded-full px-4 py-1.5 text-xs font-semibold shadow-soft transition active:scale-[0.985] disabled:opacity-60 ${prem ? "border border-border hover:border-destructive hover:text-destructive" : "bg-primary text-primary-foreground hover:brightness-[1.06]"}`}>
                    {prem ? "Desativar" : "Ativar Premium"}
                  </button>
                  <button onClick={() => setOpen(open === u.id ? null : u.id)} className="text-xs text-muted-foreground hover:text-primary">
                    Histórico ({u.history.length})
                  </button>
                </div>
              </div>
              {open === u.id && (
                <ul className="mt-3 space-y-1 border-t border-border pt-3 text-sm">
                  {u.history.length === 0 && <li className="text-muted-foreground">Sem alterações registradas.</li>}
                  {u.history.map((h, i) => (
                    <li key={i} className="flex justify-between text-muted-foreground">
                      <span>{new Date(h.created_at).toLocaleString("pt-BR")}</span>
                      <span className={h.status === "active" ? "text-primary" : ""}>{h.status === "active" ? `Ativado até ${d(h.current_period_end)}` : "Desativado"}</span>
                    </li>
                  ))}
                </ul>
              )}
            </li>
          );
        })}
      </ul>
    </main>
  );
}

function Stat({ t, v }: { t: string; v: number }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 text-center">
      <p className="text-xs uppercase tracking-wider text-muted-foreground">{t}</p>
      <p className="mt-1 text-2xl font-bold">{v}</p>
    </div>
  );
}
