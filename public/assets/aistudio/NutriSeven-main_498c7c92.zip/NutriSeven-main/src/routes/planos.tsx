import { createFileRoute, Link } from "@tanstack/react-router";
import { PlanCards } from "@/components/PlanCards";

export const Route = createFileRoute("/planos")({
  head: () => ({
    meta: [
      { title: "Planos — NutriSeven Premium" },
      { name: "description", content: "Compare o NutriSeven Grátis e Premium: histórico, gráficos, lista de compras e lembretes de água e refeições." },
      { property: "og:title", content: "Planos — NutriSeven Premium" },
      { property: "og:description", content: "Acompanhe sua evolução com gráficos, lista de compras e lembretes." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Planos,
});

function Planos() {
  return (
    <main className="mx-auto min-h-screen max-w-3xl px-4 py-12 text-center">
      <Link to="/" className="text-xs uppercase tracking-wider text-muted-foreground hover:text-primary">← Início</Link>
      <h1 className="mt-4 text-4xl font-bold tracking-tight">Escolha seu plano</h1>
      <p className="mt-2 mb-10 text-muted-foreground">Comece grátis. Evolua com o Premium quando quiser acompanhar de perto.</p>
      <PlanCards />
      <p className="mt-8 text-xs text-muted-foreground">Cancele quando quiser. Estimativas gerais, não substitui um nutricionista.</p>
    </main>
  );
}
