import { household, suggestMeal, type Budget } from "./meals";

export type ShopItem = { name: string; grams: number; unit: string; label: string };

export function weeklyList(meals: { name: string; calories: number }[], budget: Budget, days = 7): ShopItem[] {
  const acc = new Map<string, { grams: number; unit: string }>();
  meals.forEach((m, i) => {
    for (const it of suggestMeal(m.name, m.calories, budget, i)) {
      const e = acc.get(it.name) ?? { grams: 0, unit: it.unit };
      e.grams += it.grams * days;
      acc.set(it.name, e);
    }
  });
  return [...acc.entries()].map(([name, { grams, unit }]) => {
    const big = grams >= 1000 ? `${(grams / 1000).toFixed(1).replace(".", ",")} ${unit === "ml" ? "L" : "kg"}` : `${grams} ${unit}`;
    const h = household(name, grams, unit);
    return { name, grams, unit, label: h.endsWith(unit) ? big : `${big} (~${h})` };
  }).sort((a, b) => a.name.localeCompare(b.name));
}

export function weekStart(d = new Date()) {
  const x = new Date(d);
  x.setDate(x.getDate() - ((x.getDay() + 6) % 7));
  const p = (n: number) => String(n).padStart(2, "0");
  return `${x.getFullYear()}-${p(x.getMonth() + 1)}-${p(x.getDate())}`;
}
