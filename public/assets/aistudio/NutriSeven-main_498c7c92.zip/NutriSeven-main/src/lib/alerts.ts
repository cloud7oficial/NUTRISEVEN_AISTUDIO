export type Alert = { tone: "warn" | "good" | "info"; title: string; text: string };

/** Weight change between two consecutive records that triggers an alert (kg). */
export const WEIGHT_ALERT_KG = 1.5;

type W = { weight: number | string; measured_on: string };
type Meal = { name: string; calories: number };

export function buildAlerts(opts: {
  measures: W[]; // newest first
  target: number | null;
  eaten: number;
  meals: Meal[];
  doneMeals: Set<string>;
  goal: string;
  loggedDays: number;
}): Alert[] {
  const out: Alert[] = [];
  const { measures, target, eaten, meals, doneMeals, goal } = opts;

  const [cur, prev] = measures;
  if (cur && prev) {
    const d = Number(cur.weight) - Number(prev.weight);
    if (Math.abs(d) >= WEIGHT_ALERT_KG) {
      out.push({
        tone: "warn",
        title: `Peso ${d > 0 ? "subiu" : "caiu"} ${Math.abs(d).toFixed(1)} kg`,
        text: d > 0
          ? "Variação grande desde o último registro. Revise porções de carboidratos e gorduras e confira se está marcando tudo o que come."
          : "Queda rápida desde o último registro. Garanta que está comendo todas as refeições do plano e bebendo água; perdas muito rápidas podem consumir músculo.",
      });
    }
  }

  if (target) {
    const excess = eaten - target;
    if (excess > 0) {
      const remaining = meals.filter((m) => !doneMeals.has(m.name));
      const next = remaining[0];
      out.push({
        tone: "warn",
        title: `Você passou ${excess} kcal da meta de hoje`,
        text: next
          ? `Sugestão: em "${next.name}" reduza cerca de ${Math.min(excess, Math.round(next.calories * 0.5))} kcal — corte metade do carboidrato e prefira legumes e proteína magra.`
          : "Sugestão: amanhã reduza um pouco as porções de carboidrato no jantar e mantenha as proteínas. Um dia acima não estraga o progresso.",
      });
    } else if (eaten >= target * 0.9) {
      out.push({ tone: "good", title: "Meta do dia alcançada 🎯", text: `Você está em ${Math.round((eaten / target) * 100)}% das calorias de hoje.` });
    }
  }

  if (measures.length >= 2) {
    const first = measures[measures.length - 1]!;
    const total = Number(measures[0]!.weight) - Number(first.weight);
    const good = (goal === "lose" && total < 0) || (goal === "gain" && total > 0);
    if (good && Math.abs(total) >= 0.5) {
      out.push({ tone: "good", title: `Progresso: ${total > 0 ? "+" : ""}${total.toFixed(1)} kg`, text: "Desde o seu primeiro registro, você está no caminho do seu objetivo. Continue assim!" });
    }
  }

  if (opts.loggedDays >= 3) {
    out.push({ tone: "info", title: `${opts.loggedDays} dias registrados`, text: "Registrar todos os dias é o que mais faz diferença no resultado." });
  }
  return out;
}
