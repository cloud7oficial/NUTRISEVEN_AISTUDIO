export type Budget = "low" | "medium" | "varied";
type Item = [name: string, kcalPer100g: number, share: number, unit?: string];
type Kind = "breakfast" | "snack" | "main";

const menus: Record<Budget, Record<Kind, Item[][]>> = {
  low: {
    breakfast: [[["Pão francês", 290, 0.45], ["Ovo mexido", 155, 0.35], ["Banana", 89, 0.2]]],
    snack: [[["Banana", 89, 0.6], ["Aveia em flocos", 390, 0.4]]],
    main: [
      [["Arroz branco cozido", 130, 0.35], ["Feijão cozido", 76, 0.2], ["Ovo cozido", 155, 0.25], ["Salada de repolho e cenoura", 30, 0.05], ["Óleo de soja", 884, 0.15, "ml"]],
      [["Arroz branco cozido", 130, 0.35], ["Feijão cozido", 76, 0.2], ["Frango (sobrecoxa) assado", 210, 0.35], ["Salada de alface e tomate", 18, 0.1]],
    ],
  },
  medium: {
    breakfast: [[["Pão integral", 250, 0.35], ["Queijo branco", 264, 0.25], ["Iogurte natural", 61, 0.2], ["Mamão", 43, 0.2]]],
    snack: [[["Iogurte natural", 61, 0.5], ["Granola", 420, 0.3], ["Maçã", 52, 0.2]]],
    main: [
      [["Arroz integral cozido", 124, 0.3], ["Feijão cozido", 76, 0.15], ["Peito de frango grelhado", 165, 0.35], ["Legumes cozidos", 40, 0.1], ["Azeite", 884, 0.1, "ml"]],
      [["Batata-doce cozida", 86, 0.3], ["Carne moída (patinho)", 220, 0.4], ["Brócolis", 35, 0.1], ["Azeite", 884, 0.2, "ml"]],
    ],
  },
  varied: {
    breakfast: [
      [["Tapioca", 240, 0.4], ["Ovo mexido", 155, 0.3], ["Frutas vermelhas", 50, 0.15], ["Café com leite", 45, 0.15, "ml"]],
      [["Panqueca de aveia e banana", 190, 0.6], ["Pasta de amendoim", 588, 0.25], ["Morango", 32, 0.15]],
    ],
    snack: [
      [["Castanhas mistas", 600, 0.5], ["Frutas da estação", 55, 0.5]],
      [["Whey/shake de proteína", 380, 0.5], ["Banana", 89, 0.5]],
    ],
    main: [
      [["Arroz cozido", 130, 0.3], ["Salmão grelhado", 208, 0.4], ["Aspargos/legumes", 25, 0.1], ["Azeite", 884, 0.2, "ml"]],
      [["Macarrão integral cozido", 124, 0.4], ["Carne magra (alcatra)", 200, 0.35], ["Salada verde", 18, 0.1], ["Azeite", 884, 0.15, "ml"]],
      [["Quinoa cozida", 120, 0.3], ["Tilápia grelhada", 128, 0.4], ["Abobrinha", 17, 0.1], ["Abacate", 160, 0.2]],
    ],
  },
};

const kindOf = (name: string): Kind => (name.startsWith("Café") ? "breakfast" : name.startsWith("Lanche") ? "snack" : "main");

// [singular, plural, grams per unit]
const measures: Record<string, [string, string, number]> = {
  "Pão francês": ["unidade", "unidades", 50],
  "Pão integral": ["fatia", "fatias", 25],
  "Ovo mexido": ["ovo", "ovos", 50],
  "Ovo cozido": ["ovo", "ovos", 50],
  "Banana": ["banana média", "bananas médias", 100],
  "Maçã": ["maçã média", "maçãs médias", 130],
  "Mamão": ["fatia média", "fatias médias", 150],
  "Morango": ["morango", "morangos", 12],
  "Frutas vermelhas": ["xícara", "xícaras", 140],
  "Frutas da estação": ["fruta média", "frutas médias", 120],
  "Aveia em flocos": ["colher de sopa", "colheres de sopa", 15],
  "Granola": ["colher de sopa", "colheres de sopa", 12],
  "Iogurte natural": ["pote (170g)", "potes (170g)", 170],
  "Queijo branco": ["fatia", "fatias", 30],
  "Café com leite": ["xícara", "xícaras", 200],
  "Tapioca": ["tapioca média", "tapiocas médias", 70],
  "Panqueca de aveia e banana": ["panqueca", "panquecas", 80],
  "Pasta de amendoim": ["colher de sopa", "colheres de sopa", 15],
  "Castanhas mistas": ["punhado", "punhados", 30],
  "Whey/shake de proteína": ["scoop", "scoops", 30],
  "Arroz branco cozido": ["colher de servir", "colheres de servir", 45],
  "Arroz integral cozido": ["colher de servir", "colheres de servir", 45],
  "Arroz cozido": ["colher de servir", "colheres de servir", 45],
  "Feijão cozido": ["concha", "conchas", 90],
  "Óleo de soja": ["colher de sopa", "colheres de sopa", 8],
  "Azeite": ["colher de sopa", "colheres de sopa", 8],
  "Frango (sobrecoxa) assado": ["sobrecoxa", "sobrecoxas", 100],
  "Peito de frango grelhado": ["filé médio", "filés médios", 100],
  "Carne moída (patinho)": ["colher de servir", "colheres de servir", 40],
  "Carne magra (alcatra)": ["bife médio", "bifes médios", 100],
  "Salmão grelhado": ["posta média", "postas médias", 120],
  "Tilápia grelhada": ["filé", "filés", 100],
  "Batata-doce cozida": ["batata média", "batatas médias", 150],
  "Macarrão integral cozido": ["pegador", "pegadores", 60],
  "Quinoa cozida": ["colher de servir", "colheres de servir", 40],
  "Abacate": ["colher de sopa", "colheres de sopa", 30],
  "Brócolis": ["xícara", "xícaras", 90],
  "Legumes cozidos": ["xícara", "xícaras", 100],
  "Aspargos/legumes": ["xícara", "xícaras", 100],
  "Abobrinha": ["xícara", "xícaras", 100],
};

// Substitution groups: foods with similar macro profile. [name, kcal/100g, unit]
const groups: [string, number, string][][] = [
  // carbs (bread/breakfast)
  [["Pão francês", 290, "g"], ["Pão integral", 250, "g"], ["Tapioca", 240, "g"], ["Cuscuz de milho", 112, "g"], ["Panqueca de aveia e banana", 190, "g"]],
  // carbs (main dishes)
  [["Arroz branco cozido", 130, "g"], ["Arroz integral cozido", 124, "g"], ["Arroz cozido", 130, "g"], ["Batata-doce cozida", 86, "g"], ["Macarrão integral cozido", 124, "g"], ["Quinoa cozida", 120, "g"], ["Mandioca cozida", 125, "g"], ["Batata inglesa cozida", 77, "g"]],
  // legumes
  [["Feijão cozido", 76, "g"], ["Lentilha cozida", 93, "g"], ["Grão-de-bico cozido", 164, "g"]],
  // lean/medium proteins
  [["Peito de frango grelhado", 165, "g"], ["Frango (sobrecoxa) assado", 210, "g"], ["Carne moída (patinho)", 220, "g"], ["Carne magra (alcatra)", 200, "g"], ["Tilápia grelhada", 128, "g"], ["Salmão grelhado", 208, "g"], ["Atum em lata (em água)", 116, "g"], ["Ovo cozido", 155, "g"]],
  // eggs/cheese (breakfast protein)
  [["Ovo mexido", 155, "g"], ["Queijo branco", 264, "g"], ["Ricota", 140, "g"], ["Peito de peru", 110, "g"]],
  // fruits
  [["Banana", 89, "g"], ["Maçã", 52, "g"], ["Mamão", 43, "g"], ["Morango", 32, "g"], ["Frutas vermelhas", 50, "g"], ["Frutas da estação", 55, "g"], ["Laranja", 47, "g"], ["Manga", 60, "g"]],
  // cereals
  [["Aveia em flocos", 390, "g"], ["Granola", 420, "g"]],
  // dairy / protein drinks
  [["Iogurte natural", 61, "g"], ["Café com leite", 45, "ml"], ["Leite desnatado", 35, "ml"], ["Whey/shake de proteína", 380, "g"]],
  // fats
  [["Azeite", 884, "ml"], ["Óleo de soja", 884, "ml"], ["Abacate", 160, "g"], ["Pasta de amendoim", 588, "g"], ["Castanhas mistas", 600, "g"]],
  // vegetables
  [["Brócolis", 35, "g"], ["Legumes cozidos", 40, "g"], ["Aspargos/legumes", 25, "g"], ["Abobrinha", 17, "g"], ["Salada verde", 18, "g"], ["Salada de alface e tomate", 18, "g"], ["Salada de repolho e cenoura", 30, "g"], ["Cenoura cozida", 35, "g"]],
];

Object.assign(measures, {
  "Cuscuz de milho": ["xícara", "xícaras", 120],
  "Mandioca cozida": ["pedaço médio", "pedaços médios", 70],
  "Batata inglesa cozida": ["batata média", "batatas médias", 130],
  "Lentilha cozida": ["concha", "conchas", 90],
  "Grão-de-bico cozido": ["colher de sopa", "colheres de sopa", 25],
  "Atum em lata (em água)": ["lata", "latas", 120],
  "Ricota": ["fatia", "fatias", 30],
  "Peito de peru": ["fatia", "fatias", 15],
  "Laranja": ["laranja média", "laranjas médias", 150],
  "Manga": ["fatia média", "fatias médias", 100],
  "Leite desnatado": ["copo (200ml)", "copos (200ml)", 200],
  "Cenoura cozida": ["xícara", "xícaras", 100],
  "Salada verde": ["prato", "pratos", 60],
  "Salada de alface e tomate": ["prato", "pratos", 80],
  "Salada de repolho e cenoura": ["prato", "pratos", 80],
} satisfies Record<string, [string, string, number]>);

/** Returns the n-th alternative (cycling) in the same group, or the original if none. */
function swapFood(name: string, k100: number, unit: string, n: number): [string, number, string] {
  if (!n) return [name, k100, unit];
  const g = groups.find((gr) => gr.some(([f]) => f === name));
  if (!g || g.length < 2) return [name, k100, unit];
  const pos = g.findIndex(([f]) => f === name);
  return g[(pos + n) % g.length] ?? [name, k100, unit];
}

export function canSwap(name: string) {
  return groups.some((g) => g.length > 1 && g.some(([f]) => f === name));
}

export function household(name: string, grams: number, unit: string) {
  const m = measures[name];
  if (!m) return `${grams}${unit}`;
  const q = Math.max(0.5, Math.round((grams / m[2]) * 2) / 2);
  const txt = q % 1 === 0 ? String(q) : q < 1 ? "½" : `${Math.floor(q)} e ½`;
  return `${txt} ${q > 1 ? m[1] : m[0]}`;
}

/** swaps[i] = how many steps to rotate item i within its substitution group. Calorie share is preserved. */
export function suggestMeal(mealName: string, kcal: number, budget: Budget, index: number, swaps: number[] = []) {
  const options = menus[budget][kindOf(mealName)];
  const items = options[index % options.length];
  return (items ?? []).map(([orig, origK, share, origUnit = "g"], i) => {
    const [name, k100, unit] = swapFood(orig, origK, origUnit, swaps[i] ?? 0);
    const itemKcal = kcal * share;
    const grams = Math.max(5, Math.round(((itemKcal / k100) * 100) / 5) * 5);
    return { name, grams, unit, measure: household(name, grams, unit), kcal: Math.round(itemKcal), pct: Math.round(share * 100), swappable: canSwap(orig), swapped: name !== orig };
  });
}
