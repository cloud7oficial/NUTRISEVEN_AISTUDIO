import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type Ctx = { supabase: { rpc: (fn: "has_role", a: { _user_id: string; _role: "admin" }) => PromiseLike<{ data: unknown }> }; userId: string };

async function assertAdmin(context: Ctx) {
  const { data } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
  if (!data) throw new Error("Apenas administradores.");
}

async function applyPremium(target: string, active: boolean, by: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const end = new Date(); end.setMonth(end.getMonth() + 1);
  const status = active ? "active" : "inactive";
  const current_period_end = active ? end.toISOString() : null;
  const { error } = await supabaseAdmin.from("subscriptions").upsert({ user_id: target, status, current_period_end, updated_at: new Date().toISOString() });
  if (error) throw new Error("Erro ao salvar.");
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  await (supabaseAdmin as any).from("subscription_events").insert({ user_id: target, status, current_period_end, changed_by: by });
}

/** Admin-only: activate (or deactivate) Premium for a user by email. */
export const setPremiumByEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { email: string; active: boolean }) => ({ email: String(d.email).trim().toLowerCase(), active: !!d.active }))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as unknown as Ctx);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let target: string | undefined;
    for (let page = 1; page <= 20 && !target; page++) {
      const { data: list, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 200 });
      if (error) throw new Error("Erro ao buscar usuários.");
      target = list.users.find((u) => u.email?.toLowerCase() === data.email)?.id;
      if (list.users.length < 200) break;
    }
    if (!target) throw new Error("Usuário não encontrado.");
    await applyPremium(target, data.active, context.userId);
    return { ok: true };
  });

/** Admin-only: activate/deactivate Premium by user id. */
export const setPremiumById = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; active: boolean }) => ({ userId: String(d.userId), active: !!d.active }))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as unknown as Ctx);
    await applyPremium(data.userId, data.active, context.userId);
    return { ok: true };
  });

export type AdminUser = {
  id: string; email: string; created_at: string; last_sign_in_at: string | null;
  status: string | null; current_period_end: string | null;
  history: { status: string; current_period_end: string | null; created_at: string }[];
};

/** Admin-only: all users with subscription and history. */
export const listUsersAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AdminUser[]> => {
    await assertAdmin(context as unknown as Ctx);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const users: { id: string; email?: string; created_at: string; last_sign_in_at?: string | null }[] = [];
    for (let page = 1; page <= 20; page++) {
      const { data: list, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 200 });
      if (error) throw new Error("Erro ao buscar usuários.");
      users.push(...list.users);
      if (list.users.length < 200) break;
    }
    const { data: subs } = await supabaseAdmin.from("subscriptions").select("user_id,status,current_period_end");
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: evs } = await (supabaseAdmin as any).from("subscription_events").select("user_id,status,current_period_end,created_at").order("created_at", { ascending: false }).limit(2000);
    return users.map((u) => {
      const s = subs?.find((x) => x.user_id === u.id);
      return {
        id: u.id, email: u.email ?? "", created_at: u.created_at, last_sign_in_at: u.last_sign_in_at ?? null,
        status: s?.status ?? null, current_period_end: s?.current_period_end ?? null,
        history: ((evs ?? []) as { user_id: string; status: string; current_period_end: string | null; created_at: string }[])
          .filter((e) => e.user_id === u.id).map(({ status, current_period_end, created_at }) => ({ status, current_period_end, created_at })),
      };
    }).sort((a, b) => b.created_at.localeCompare(a.created_at));
  });
