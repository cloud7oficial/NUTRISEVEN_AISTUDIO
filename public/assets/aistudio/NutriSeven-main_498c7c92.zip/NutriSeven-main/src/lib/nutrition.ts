export type Sex = "male" | "female";
export type Goal = "lose" | "maintain" | "gain";
export type Activity = "sedentary" | "light" | "moderate" | "active" | "very";

export const activityFactors: Record<Activity, number> = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  active: 1.725,
  very: 1.9,
};

export interface Input {
  sex: Sex;
  age: number;
  height: number; // cm
  weight: number; // kg
  goal: Goal;
  activity: Activity;
}

export function calculate(i: Input) {
  // Mifflin-St Jeor
  const bmr = 10 * i.weight + 6.25 * i.height - 5 * i.age + (i.sex === "male" ? 5 : -161);
  const tdee = bmr * activityFactors[i.activity];
  const calories = Math.round(i.goal === "lose" ? tdee - 500 : i.goal === "gain" ? tdee + 300 : tdee);
  const proteinPerKg = i.goal === "lose" ? 2.0 : i.goal === "gain" ? 1.8 : 1.6;
  const protein = Math.round(i.weight * proteinPerKg);
  const fat = Math.round((calories * 0.25) / 9);
  const carbs = Math.max(0, Math.round((calories - protein * 4 - fat * 9) / 4));
  const meals = i.goal === "gain" ? 5 : i.goal === "lose" ? 4 : 4;
  const split =
    meals === 5
      ? [
          ["Café da manhã", 0.25],
          ["Lanche da manhã", 0.1],
          ["Almoço", 0.3],
          ["Lanche da tarde", 0.1],
          ["Jantar", 0.25],
        ]
      : [
          ["Café da manhã", 0.25],
          ["Almoço", 0.35],
          ["Lanche da tarde", 0.15],
          ["Jantar", 0.25],
        ];
  const mealPlan = (split as [string, number][]).map(([name, pct]) => ({
    name,
    pct: Math.round(pct * 100),
    calories: Math.round(calories * pct),
  }));
  return { bmr: Math.round(bmr), tdee: Math.round(tdee), calories, protein, fat, carbs, meals, mealPlan };
}
