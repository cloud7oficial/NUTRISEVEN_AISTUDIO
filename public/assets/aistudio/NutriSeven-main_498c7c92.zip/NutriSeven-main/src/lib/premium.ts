export const PREMIUM_PRICE = "R$ 14,99";
export const WATER_ML_PER_KG = 35;
export const GLASS_ML = 250;

export function waterGoal(weightKg: number) {
  return Math.round((weightKg * WATER_ML_PER_KG) / 50) * 50;
}

type Sub = { status: string; current_period_end: string | null } | null | undefined;

/** Premium only when active/trialing and the paid period hasn't ended. */
export function isPremium(sub: Sub, now = new Date()) {
  if (!sub || !["active", "trialing"].includes(sub.status)) return false;
  return !sub.current_period_end || new Date(sub.current_period_end) > now;
}

/** Swapping foods in the calculator is a Premium-only feature. */
export function canSwapFood(premium: boolean) {
  return premium;
}
