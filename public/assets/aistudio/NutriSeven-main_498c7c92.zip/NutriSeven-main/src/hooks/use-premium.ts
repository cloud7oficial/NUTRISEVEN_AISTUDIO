import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { isPremium } from "@/lib/premium";

/** Current user's Premium status (browser only). */
export function usePremium() {
  const [userId, setUserId] = useState<string | null | undefined>(undefined);
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null));
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setUserId(s?.user.id ?? null));
    return () => data.subscription.unsubscribe();
  }, []);
  const sub = useQuery({
    queryKey: ["subscription", userId],
    enabled: !!userId,
    queryFn: async () => (await supabase.from("subscriptions").select("status,current_period_end").eq("user_id", userId!).maybeSingle()).data,
  });
  const loading = userId === undefined || (!!userId && sub.isLoading);
  return { premium: isPremium(sub.data), loading, signedIn: !!userId };
}
