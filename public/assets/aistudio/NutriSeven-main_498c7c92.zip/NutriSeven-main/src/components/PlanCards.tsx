import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { PREMIUM_PRICE } from "@/lib/premium";

const free = ["Calculadora de calorias e macros", "Número de refeições e divisão de calorias", "Sugestão de cardápio com medidas caseiras"];
const premium = ["Tudo do Grátis", "Trocar alimentos do cardápio", "Conta com registro de peso e medidas", "Plano do dia com marcação do que comeu", "Notificações de progresso e alertas", "Histórico de consumo diário", "Gráfico de evolução de peso e medidas", "Lista de compras da semana", "Lembretes de água e de refeições"];

export function PlanCards() {
  const [msg, setMsg] = useState(false);
  return (
    <div className="grid w-full gap-4 text-left sm:grid-cols-2">
      <div className="rounded-2xl border border-border bg-card p-6">
        <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Grátis</p>
        <p className="mt-2 text-4xl font-bold">R$ 0</p>
        <ul className="mt-5 space-y-2 text-sm">{free.map((f) => <li key={f}>✓ {f}</li>)}</ul>
        <Link to="/calculadora" className="mt-6 block rounded-full border border-border py-3 text-center text-sm font-semibold hover:border-primary">Começar grátis</Link>
      </div>
      <div className="rounded-2xl border-2 border-primary bg-card p-6 shadow-soft">
        <p className="text-sm font-semibold uppercase tracking-wider text-primary">Premium</p>
        <p className="mt-2 text-4xl font-bold">{PREMIUM_PRICE}<span className="text-base font-normal text-muted-foreground">/mês</span></p>
        <ul className="mt-5 space-y-2 text-sm">{premium.map((f) => <li key={f}>✓ {f}</li>)}</ul>
        <button onClick={() => setMsg(true)} className="mt-6 w-full rounded-full bg-primary py-3 text-sm font-semibold text-primary-foreground shadow-soft transition hover:brightness-[1.06] active:scale-[0.985]">Assinar Premium</button>
        {msg && <p role="status" className="mt-3 text-center text-sm text-muted-foreground">As assinaturas abrem em breve! Crie sua conta para ser avisado.</p>}
      </div>
    </div>
  );
}

