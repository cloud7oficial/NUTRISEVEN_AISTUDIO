import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { setPremiumByEmail } from "@/lib/admin.functions";

const card = "rounded-xl border border-border bg-card p-6";
const btn = "rounded-full bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground shadow-soft transition hover:brightness-[1.06] active:scale-[0.985] disabled:opacity-60";
const ghost = "rounded-full border border-border px-6 py-2.5 text-sm font-semibold transition hover:border-primary disabled:opacity-60";

export function DownloadData({ userId }: { userId: string }) {
  const [busy, setBusy] = useState(false);
  const run = async () => {
    setBusy(true);
    const t = (n: "profiles" | "measurements" | "food_logs" | "water_logs" | "meal_reminders" | "shopping_checks") =>
      n === "profiles" ? supabase.from(n).select("*").eq("id", userId) : supabase.from(n).select("*").eq("user_id", userId);
    const names = ["profiles", "measurements", "food_logs", "water_logs", "meal_reminders", "shopping_checks"] as const;
    const res = await Promise.all(names.map((n) => t(n)));
    const out: Record<string, unknown> = { exportado_em: new Date().toISOString() };
    names.forEach((n, i) => (out[n === "profiles" ? "perfil" : n] = n === "profiles" ? res[i]!.data?.[0] ?? null : res[i]!.data ?? []));
    const blob = new Blob([JSON.stringify(out, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `nutriseven-meus-dados-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30_000);
    setBusy(false);
  };
  return (
    <section className={card}>
      <h2 className="text-lg font-semibold">Meus dados</h2>
      <p className="mt-1 text-sm text-muted-foreground">Baixe todo o seu conteúdo: cadastro, medidas, consumo, água, lembretes e lista de compras.</p>
      <button onClick={run} disabled={busy} className={`${btn} mt-4`}>{busy ? "Preparando…" : "⬇ Baixar todo o conteúdo"}</button>
    </section>
  );
}

export function AdminPremium({ userId }: { userId: string }) {
  const qc = useQueryClient();
  const setPremium = useServerFn(setPremiumByEmail);
  const admin = useQuery({
    queryKey: ["is_admin", userId],
    queryFn: async () => (await supabase.rpc("has_role", { _user_id: userId, _role: "admin" })).data === true,
  });
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  if (!admin.data) return null;
  const go = async (active: boolean) => {
    if (!email.includes("@")) return setMsg("Informe um e-mail válido.");
    setBusy(true); setMsg("");
    try {
      await setPremium({ data: { email, active } });
      setMsg(active ? "Premium ativado ✓" : "Premium desativado ✓");
      qc.invalidateQueries({ queryKey: ["subscription"] });
    } catch (e) { setMsg(e instanceof Error ? e.message : "Erro."); }
    setBusy(false);
  };
  return (
    <section className={`${card} text-left`}>
      <h2 className="text-lg font-semibold">Administração · Ativar Premium</h2>
      <p className="mt-1 text-sm text-muted-foreground">Visível só para administradores.</p>
      <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@do-usuario.com"
        className="mt-4 w-full rounded-md border border-input bg-input/40 px-3 py-2 text-foreground outline-none focus:border-primary" />
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <button onClick={() => go(true)} disabled={busy} className={btn}>Ativar Premium</button>
        <button onClick={() => go(false)} disabled={busy} className={ghost}>Desativar</button>
        {msg && <span className="text-sm text-muted-foreground">{msg}</span>}
      </div>
    </section>
  );
}
