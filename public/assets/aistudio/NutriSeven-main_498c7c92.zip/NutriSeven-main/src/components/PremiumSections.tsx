import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { fmtDate, today } from "@/lib/dates";
import { GLASS_ML, waterGoal } from "@/lib/premium";
import { weekStart, weeklyList } from "@/lib/shopping";
import type { Budget } from "@/lib/meals";

const card = "rounded-xl border border-border bg-card p-6";

export function Locked({ title, text }: { title: string; text: string }) {
  return (
    <section className={`${card} text-center`}>
      <p className="text-xs font-semibold uppercase tracking-wider text-primary">Premium</p>
      <h2 className="mt-1 text-lg font-semibold">🔒 {title}</h2>
      <p className="mt-1 text-sm text-muted-foreground">{text}</p>
      <Link to="/planos" className="mt-4 inline-block rounded-full bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground shadow-soft hover:brightness-[1.06]">Desbloqueie no Premium</Link>
    </section>
  );
}

type M = { measured_on: string; weight: number; waist: number | null; hip: number | null; arm: number | null; thigh: number | null; body_fat: number | null };

export function EvolutionChart({ data }: { data: M[] }) {
  const [range, setRange] = useState<30 | 90 | 0>(30);
  const rows = useMemo(() => {
    const min = new Date(); min.setDate(min.getDate() - range);
    return [...data].filter((r) => !range || r.measured_on >= today(min)).reverse()
      .map((r) => ({ d: fmtDate(r.measured_on), Peso: Number(r.weight), Cintura: r.waist, Quadril: r.hip, Braço: r.arm, Coxa: r.thigh, "% Gordura": r.body_fat }));
  }, [data, range]);
  const small = ["Cintura", "Quadril", "Braço", "Coxa", "% Gordura"] as const;
  const tip = { background: "var(--color-card)", border: "1px solid var(--color-border)", borderRadius: 8 };
  return (
    <section className={card}>
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Gráfico de evolução</h2>
        <div className="flex gap-1 text-xs">
          {([[30, "30 dias"], [90, "90 dias"], [0, "Tudo"]] as const).map(([v, t]) => (
            <button key={v} onClick={() => setRange(v)} className={`rounded-full px-3 py-1 ${range === v ? "bg-primary text-primary-foreground" : "border border-border"}`}>{t}</button>
          ))}
        </div>
      </div>
      {rows.length < 2 ? <p className="mt-3 text-sm text-muted-foreground">Registre pelo menos 2 medições para ver o gráfico.</p> : (
        <>
          <div className="mt-4 h-56">
            <ResponsiveContainer>
              <LineChart data={rows}><CartesianGrid stroke="var(--color-border)" strokeDasharray="3 3" />
                <XAxis dataKey="d" stroke="var(--color-muted-foreground)" fontSize={11} /><YAxis domain={["auto", "auto"]} stroke="var(--color-muted-foreground)" fontSize={11} width={36} />
                <Tooltip contentStyle={tip} /><Line type="monotone" dataKey="Peso" stroke="var(--color-primary)" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-5">
            {small.filter((k) => rows.some((r) => r[k] != null)).map((k) => (
              <div key={k} className="rounded-lg border border-border p-2">
                <p className="text-xs text-muted-foreground">{k}</p>
                <div className="h-14"><ResponsiveContainer><LineChart data={rows}><Line type="monotone" dataKey={k} stroke="var(--color-primary)" dot={false} connectNulls /></LineChart></ResponsiveContainer></div>
              </div>
            ))}
          </div>
        </>
      )}
    </section>
  );
}

export function ShoppingList({ userId, meals, budget }: { userId: string; meals: { name: string; calories: number }[]; budget: Budget }) {
  const qc = useQueryClient();
  const week = weekStart();
  const items = useMemo(() => weeklyList(meals, budget), [meals, budget]);
  const checks = useQuery({
    queryKey: ["shopping", userId, week],
    queryFn: async () => (await supabase.from("shopping_checks").select("id,item").eq("week_start", week)).data ?? [],
  });
  const toggle = async (name: string) => {
    const ex = checks.data?.find((c) => c.item === name);
    if (ex) await supabase.from("shopping_checks").delete().eq("id", ex.id);
    else await supabase.from("shopping_checks").insert({ user_id: userId, week_start: week, item: name });
    qc.invalidateQueries({ queryKey: ["shopping", userId, week] });
  };
  const text = "🛒 Lista de compras NutriSeven (7 dias)\n" + items.map((i) => `• ${i.name}: ${i.label}`).join("\n");
  const [copied, setCopied] = useState(false);
  return (
    <section className={card}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-lg font-semibold">Lista de compras da semana</h2>
        <div className="flex gap-2 text-xs">
          <button onClick={() => { navigator.clipboard.writeText(text); setCopied(true); }} className="rounded-full border border-border px-3 py-1.5 hover:border-primary">{copied ? "Copiado ✓" : "Copiar"}</button>
          <a href={`https://wa.me/?text=${encodeURIComponent(text)}`} target="_blank" rel="noreferrer" className="rounded-full bg-primary px-3 py-1.5 font-semibold text-primary-foreground">WhatsApp</a>
        </div>
      </div>
      <ul className="mt-3 grid gap-1.5 text-sm sm:grid-cols-2">
        {items.map((i) => {
          const done = checks.data?.some((c) => c.item === i.name) ?? false;
          return (
            <li key={i.name}><label className="flex cursor-pointer items-center gap-2">
              <input type="checkbox" checked={done} onChange={() => toggle(i.name)} className="h-4 w-4 accent-[var(--color-primary)]" />
              <span className={done ? "text-muted-foreground line-through" : ""}>{i.name}</span>
              <span className="ml-auto text-right text-xs text-muted-foreground">{i.label}</span>
            </label></li>
          );
        })}
      </ul>
    </section>
  );
}

const DEFAULT_TIMES: Record<string, string> = { "Café da manhã": "07:30", "Lanche da manhã": "10:00", "Almoço": "12:30", "Lanche da tarde": "16:00", "Jantar": "19:30" };

export function WaterReminders({ userId, weight, meals }: { userId: string; weight: number; meals: string[] }) {
  const qc = useQueryClient();
  const day = today();
  const goal = waterGoal(weight);
  const water = useQuery({
    queryKey: ["water", userId, day],
    queryFn: async () => (await supabase.from("water_logs").select("id,ml").eq("log_date", day).maybeSingle()).data,
  });
  const reminders = useQuery({
    queryKey: ["reminders", userId],
    queryFn: async () => (await supabase.from("meal_reminders").select("meal_name,time")).data ?? [],
  });
  const ml = water.data?.ml ?? 0;
  const addWater = async (delta: number) => {
    const next = Math.max(0, ml + delta);
    await supabase.from("water_logs").upsert({ user_id: userId, log_date: day, ml: next }, { onConflict: "user_id,log_date" });
    qc.invalidateQueries({ queryKey: ["water", userId, day] });
  };
  const times = Object.fromEntries(meals.map((m) => [m, reminders.data?.find((r) => r.meal_name === m)?.time ?? DEFAULT_TIMES[m] ?? "12:00"]));
  const setTime = async (meal: string, time: string) => {
    await supabase.from("meal_reminders").upsert({ user_id: userId, meal_name: meal, time }, { onConflict: "user_id,meal_name" });
    qc.invalidateQueries({ queryKey: ["reminders", userId] });
  };

  const [perm, setPerm] = useState<string>("default");
  const [banner, setBanner] = useState("");
  useEffect(() => { if ("Notification" in window) setPerm(Notification.permission); }, []);
  const timesKey = JSON.stringify(times);
  useEffect(() => {
    const fired = new Set<string>();
    const check = () => {
      const now = new Date();
      const hm = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
      let msg = "";
      for (const [meal, t] of Object.entries(JSON.parse(timesKey) as Record<string, string>)) if (t === hm) msg = `Hora do ${meal.toLowerCase()}! 🍽️`;
      if (!msg && now.getMinutes() === 0 && now.getHours() >= 8 && now.getHours() <= 21) msg = "Hora de beber um copo de água 💧";
      if (msg && !fired.has(hm)) {
        fired.add(hm); setBanner(msg);
        if ("Notification" in window && Notification.permission === "granted") new Notification("NutriSeven", { body: msg });
      }
    };
    const id = window.setInterval(check, 30000);
    return () => window.clearInterval(id);
  }, [timesKey]);

  return (
    <section className={card}>
      <h2 className="text-lg font-semibold">Água e lembretes</h2>
      {banner && <div role="status" className="mt-3 flex items-center justify-between rounded-lg border border-primary/50 bg-primary/10 p-3 text-sm"><span>{banner}</span><button onClick={() => setBanner("")} aria-label="Fechar">✕</button></div>}
      <div className="mt-4 flex items-end justify-between">
        <p><span className="text-3xl font-bold text-primary">{(ml / 1000).toFixed(2).replace(".", ",")}</span> <span className="text-muted-foreground">/ {(goal / 1000).toFixed(1).replace(".", ",")} L</span></p>
        <div className="flex gap-2">
          <button onClick={() => addWater(-GLASS_ML)} className="rounded-full border border-border px-3 py-1.5 text-sm">−</button>
          <button onClick={() => addWater(GLASS_ML)} className="rounded-full bg-primary px-4 py-1.5 text-sm font-semibold text-primary-foreground">+1 copo (250 ml)</button>
        </div>
      </div>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-muted"><div className="h-full bg-primary transition-all" style={{ width: `${Math.min(100, (ml / goal) * 100)}%` }} /></div>
      <p className="mt-1 text-xs text-muted-foreground">Meta: 35 ml por kg de peso.</p>

      <h3 className="mt-6 text-sm font-semibold">Horários das refeições</h3>
      <div className="mt-2 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {meals.map((m) => (
          <label key={m} className="space-y-1 text-sm"><span className="text-muted-foreground">{m}</span>
            <input type="time" value={times[m]} onChange={(e) => setTime(m, e.target.value)} className="w-full rounded-md border border-input bg-input/40 px-3 py-2" />
          </label>
        ))}
      </div>
      {perm !== "granted" && "Notification" in globalThis && (
        <button onClick={async () => setPerm(await Notification.requestPermission())} className="mt-4 rounded-full border border-border px-4 py-2 text-sm hover:border-primary">🔔 Ativar avisos no navegador</button>
      )}
      <p className="mt-2 text-xs text-muted-foreground">Os avisos aparecem enquanto o NutriSeven estiver aberto.</p>
    </section>
  );
}
