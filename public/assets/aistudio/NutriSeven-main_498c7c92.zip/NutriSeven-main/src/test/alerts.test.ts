import { describe, it, expect } from "vitest";
import { buildAlerts } from "@/lib/alerts";

const base = { target: 2000, eaten: 0, meals: [{ name: "Jantar", calories: 600 }], doneMeals: new Set<string>(), goal: "lose", loggedDays: 0 };

describe("buildAlerts", () => {
  it("alerts when weight changes 1.5 kg or more", () => {
    const a = buildAlerts({ ...base, measures: [{ weight: 81.5, measured_on: "2026-10-19" }, { weight: 80, measured_on: "2026-10-12" }] });
    expect(a.some((x) => x.title.includes("subiu 1.5 kg"))).toBe(true);
  });
  it("does not alert on a 1 kg change", () => {
    const a = buildAlerts({ ...base, measures: [{ weight: 81, measured_on: "b" }, { weight: 80, measured_on: "a" }] });
    expect(a.some((x) => x.title.startsWith("Peso"))).toBe(false);
  });
  it("alerts when eating over the daily target", () => {
    const a = buildAlerts({ ...base, measures: [], eaten: 2300 });
    expect(a.some((x) => x.title.includes("300 kcal"))).toBe(true);
  });
});
