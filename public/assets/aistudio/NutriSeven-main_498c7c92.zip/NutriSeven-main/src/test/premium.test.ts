import { describe, it, expect } from "vitest";
import { isPremium, waterGoal } from "@/lib/premium";
import { weeklyList } from "@/lib/shopping";
import { suggestMeal } from "@/lib/meals";

describe("premium rules", () => {
  it("water goal is 35 ml per kg", () => {
    expect(waterGoal(80)).toBe(2800);
  });
  it("active subscription within period is premium", () => {
    expect(isPremium({ status: "active", current_period_end: "2099-01-01" })).toBe(true);
  });
  it("expired or inactive subscription is not premium", () => {
    expect(isPremium({ status: "active", current_period_end: "2000-01-01" })).toBe(false);
    expect(isPremium({ status: "inactive", current_period_end: null })).toBe(false);
    expect(isPremium(null)).toBe(false);
  });
  it("weekly list multiplies daily grams by 7", () => {
    const meals = [{ name: "Almoço", calories: 700 }];
    const day = suggestMeal("Almoço", 700, "low", 0);
    const list = weeklyList(meals, "low");
    const item = list.find((x) => x.name === day[0]!.name)!;
    expect(item.grams).toBe(day[0]!.grams * 7);
  });
});

import { canSwapFood } from "@/lib/premium";
describe("free plan", () => {
  it("cannot swap foods; premium can", () => {
    expect(canSwapFood(false)).toBe(false);
    expect(canSwapFood(true)).toBe(true);
  });
});
