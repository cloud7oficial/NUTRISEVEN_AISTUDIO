# NutriSeven

Por favor, crie um aplicativo simples de calculadora de calorias e macronutrientes chamado NutriSeven. Quero que os usuários possam inserir seu sexo, idade, altura, peso, seu objetivo (perder peso, ganhar peso ou manter o peso) e seu nível de atividade. Em seguida, o aplicativo deve calcular e mostrar a quantidade diária recomendada de calorias, proteínas, gorduras e carboidratos. Também quero que o aplicativo sugira quantas refeições eles devem fazer por dia e como distribuir as calorias entre essas refeições. Use um tema de cores verde e cinza escuro. Mantenha o design simples e limpo.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://daily-macro-meal-map.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/d19a9d9e-deab-4c07-a7e2-3000591e806a).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
