CREATE TABLE public.subscriptions (
  user_id uuid PRIMARY KEY,
  status text NOT NULL DEFAULT 'inactive',
  plan text NOT NULL DEFAULT 'premium_monthly',
  current_period_end timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.subscriptions TO authenticated;
GRANT ALL ON public.subscriptions TO service_role;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own subscription read" ON public.subscriptions FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE TABLE public.water_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  log_date date NOT NULL DEFAULT current_date,
  ml int NOT NULL DEFAULT 0,
  UNIQUE (user_id, log_date)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.water_logs TO authenticated;
GRANT ALL ON public.water_logs TO service_role;
ALTER TABLE public.water_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own water" ON public.water_logs FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.meal_reminders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  meal_name text NOT NULL,
  time text NOT NULL,
  UNIQUE (user_id, meal_name)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.meal_reminders TO authenticated;
GRANT ALL ON public.meal_reminders TO service_role;
ALTER TABLE public.meal_reminders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own reminders" ON public.meal_reminders FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.shopping_checks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  week_start date NOT NULL,
  item text NOT NULL,
  UNIQUE (user_id, week_start, item)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.shopping_checks TO authenticated;
GRANT ALL ON public.shopping_checks TO service_role;
ALTER TABLE public.shopping_checks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own shopping" ON public.shopping_checks FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);